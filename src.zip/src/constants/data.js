import IImages from "./IImages";

const imageHero = [];
export default { imageHero };
