import logo from "../assets/logo.png";
import ImageComingSoon from "../assets/imagecommingsoon.jpeg";
import car from "../assets/car.png";
import order from "../assets/order.png";
import payment from "../assets/payment.png";
import returnOrder from "../assets/returnOrder.png";
import school_logo_demo from "../assets/school_logo_demo.png";
import Return from "../assets/Return.png";

export default {
  logo,
  car,
  order,
  payment,
  returnOrder,
  ImageComingSoon,
  school_logo_demo,
  Return,
};
